import React from 'react'
import Navbar from './components/Navbar'
import Section1 from './components/Section1'
import Section2 from './components/Section2'
import Cardsection from './components/Cardsection'
import Footer from './components/Footer'
import './style.css'



const App = () => {

    return (
        <div>
          < Navbar />
          < Section2 />
          <Section1 />
          < Cardsection />
          < Footer />
        </div>
        
        
    )

}
export default App;