import React from 'react'
import Image from './Image'

const Card= ({image,cardTitle,cardDescription,buttonText})=>{

    return (
        <div className="col-4">
        <div className="card" style={{width: "18 rem"}}>
        <Image image = {image} className="card-img-top"/>
         
          <div className="card-body">
            <h5 className="card-title">{cardTitle}</h5>
            <p className="card-text">
             {cardDescription}
            </p>
            <a href="#" className="btn btn-success">{buttonText}</a>
          </div>
        </div>
      </div>


    )
}

export default Card