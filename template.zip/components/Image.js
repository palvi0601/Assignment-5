

const Image = ({image})=>{
    return (
        <img 
        src={image}
        alt="..." className = "img"
      />
    )
}
export default Image